import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { portfolioConfig } from '../data/portfolioConfig';
import { useDeviceCapabilities } from '../hooks/useDeviceCapabilities';

gsap.registerPlugin(ScrollTrigger);

interface Particle {
  origX: number;
  origY: number;
  r: number;
  g: number;
  b: number;
  targetR: number;
  targetG: number;
  targetB: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  delay: number;
  spin: number;
}

const GLOW_PALETTE: Array<[number, number, number]> = [
  [255, 85, 127], // #FF557F Crimson Red
  [146, 114, 255], // #9272FF Purple
  [196, 77, 158], // #C44D9E Pink
];

interface PortraitDisintegrationProps {
  src: string;
  alt: string;
}

export function PortraitDisintegration({ src, alt }: PortraitDisintegrationProps) {
  const { reducedMotion, isCompactViewport } = useDeviceCapabilities();
  const wrapperRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const [imageError, setImageError] = useState(false);
  const [particlesReady, setParticlesReady] = useState(false);

  useEffect(() => {
    const wrapper = wrapperRef.current;
    const canvas = canvasRef.current;
    const imgEl = imgRef.current;
    if (!wrapper || !canvas || !imgEl || reducedMotion || imageError) {
      setParticlesReady(false);
      return;
    }

    let cancelled = false;
    let particles: Particle[] = [];
    let canvasW = 0;
    let canvasH = 0;
    let imgOffsetX = 0;
    let imgOffsetY = 0;
    let frameW = 0;
    let frameH = 0;
    let scrollTriggerInstance: ScrollTrigger | null = null;
    let currentProgress = 0;

    const buildParticles = (loadedImg: HTMLImageElement) => {
      if (cancelled || !wrapper || !canvas) return;

      const rect = wrapper.getBoundingClientRect();
      frameW = Math.max(200, Math.round(rect.width));
      frameH = Math.max(240, Math.round(rect.height));

      // Canvas extends past the portrait frame so 3D particles disperse freely outward
      const padX = isCompactViewport ? 48 : 96;
      const padY = isCompactViewport ? 48 : 88;
      canvasW = frameW + padX * 2;
      canvasH = frameH + padY * 2;
      imgOffsetX = padX;
      imgOffsetY = padY;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(canvasW * dpr);
      canvas.height = Math.round(canvasH * dpr);
      canvas.style.width = `${canvasW}px`;
      canvas.style.height = `${canvasH}px`;
      canvas.style.left = `${-padX}px`;
      canvas.style.top = `${-padY}px`;

      // Draw image onto offscreen canvas matching CSS `object-cover object-top`
      const offscreen = document.createElement('canvas');
      offscreen.width = frameW;
      offscreen.height = frameH;
      const offCtx = offscreen.getContext('2d');
      if (!offCtx) return;

      const natW = loadedImg.naturalWidth || loadedImg.width;
      const natH = loadedImg.naturalHeight || loadedImg.height;
      const scale = Math.max(frameW / natW, frameH / natH);
      const drawW = natW * scale;
      const drawH = natH * scale;
      const drawX = (frameW - drawW) / 2;
      const drawY = 0; // object-top alignment

      offCtx.drawImage(loadedImg, drawX, drawY, drawW, drawH);

      let pixelData: Uint8ClampedArray;
      try {
        pixelData = offCtx.getImageData(0, 0, frameW, frameH).data;
      } catch {
        setParticlesReady(false);
        return;
      }

      // Adaptive sampling step to keep particle count optimal per device
      const step = isCompactViewport ? 9 : 6;
      const centerX = frameW * 0.5;
      const centerY = frameH * 0.44;
      const nextParticles: Particle[] = [];

      for (let py = 0; py < frameH; py += step) {
        for (let px = 0; px < frameW; px += step) {
          const idx = (py * frameW + px) * 4;
          const r = pixelData[idx];
          const g = pixelData[idx + 1];
          const b = pixelData[idx + 2];
          const a = pixelData[idx + 3];

          if (a < 40) continue;

          // Skip uniform bright white studio backdrop far from edges so the portrait silhouette pops cleanly
          const isStudioWhite = r > 240 && g > 240 && b > 240;
          if (isStudioWhite && ((px + py) % (step * 3) !== 0)) continue;

          const dx = px - centerX;
          const dy = py - centerY;
          const dist = Math.hypot(dx, dy) || 1;
          const normX = dx / dist;
          const normY = dy / dist;

          // Deterministic pseudo-random based on coordinates so scroll reconstruction is 100% reproducible
          const seed1 = Math.sin(px * 12.9898 + py * 78.233) * 43758.5453;
          const rand1 = seed1 - Math.floor(seed1);
          const seed2 = Math.sin(px * 39.346 + py * 11.135) * 24634.6345;
          const rand2 = seed2 - Math.floor(seed2);

          const [targetR, targetG, targetB] =
            GLOW_PALETTE[Math.floor(rand1 * GLOW_PALETTE.length) % GLOW_PALETTE.length];

          const radialSpeed = (isCompactViewport ? 85 : 150) + rand1 * (isCompactViewport ? 120 : 210);
          const vx = normX * radialSpeed + (rand2 - 0.5) * 90;
          const vy = normY * radialSpeed - 35 + (rand1 - 0.5) * 85;
          const vz = (rand2 - 0.35) * 320; // Move outward toward/away in 3D space

          // Outer edge pixels begin dissolving slightly earlier than inner face
          const edgeFactor = Math.min(1, dist / (Math.max(frameW, frameH) * 0.55));
          const delay = (1 - edgeFactor) * 0.16 + rand1 * 0.06;

          nextParticles.push({
            origX: imgOffsetX + px,
            origY: imgOffsetY + py,
            r,
            g,
            b,
            targetR,
            targetG,
            targetB,
            vx,
            vy,
            vz,
            size: isStudioWhite ? 1.15 : 1.55 + rand2 * 1.15,
            delay,
            spin: (rand1 - 0.5) * 2.4,
          });
        }
      }

      particles = nextParticles;
      setParticlesReady(true);
      renderAtProgress(currentProgress);
    };

    const renderAtProgress = (rawProgress: number) => {
      currentProgress = Math.max(0, Math.min(1, rawProgress));
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, canvasW, canvasH);

      // Update underlying accessible portrait opacity smoothly in both directions
      if (imgEl) {
        const photoOpacity =
          currentProgress <= 0.02
            ? 1
            : currentProgress >= 0.22
              ? 0
              : 1 - (currentProgress - 0.02) / 0.2;
        imgEl.style.opacity = String(photoOpacity);
      }

      // Skip drawing particles when completely at rest (sharp photo is visible)
      if (currentProgress <= 0.005 || particles.length === 0) {
        return;
      }

      // Fade particle layer cleanly in over [0.005 -> 0.08] and out at [0.82 -> 1.0]
      const layerAlphaIn = Math.min(1, currentProgress / 0.08);
      const layerAlphaOut = currentProgress > 0.8 ? Math.max(0, 1 - (currentProgress - 0.8) / 0.2) : 1;
      const globalAlpha = layerAlphaIn * layerAlphaOut;
      if (globalAlpha <= 0.01) return;

      const focalLength = 480;
      const originCenterX = imgOffsetX + frameW * 0.5;
      const originCenterY = imgOffsetY + frameH * 0.48;

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        const localT = Math.max(0, Math.min(1, (currentProgress - p.delay) / (1 - p.delay)));
        const ease = 1 - Math.pow(1 - localT, 2.15);

        // 3D world offset with gentle orbital curl
        const curlAngle = ease * p.spin;
        const cosA = Math.cos(curlAngle);
        const sinA = Math.sin(curlAngle);
        const dx = p.vx * ease;
        const dy = p.vy * ease;

        const worldX = p.origX + (dx * cosA - dy * sinA * 0.35);
        const worldY = p.origY + (dy * cosA + dx * sinA * 0.35);
        const worldZ = p.vz * ease;

        // Perspective projection relative to portrait center
        const depth = Math.max(90, focalLength - worldZ);
        const perspScale = focalLength / depth;
        const screenX = originCenterX + (worldX - originCenterX) * perspScale;
        const screenY = originCenterY + (worldY - originCenterY) * perspScale;

        // Blend from true photo pixel color to glowing crimson/purple/pink
        const colorMix = Math.min(1, ease * 1.45);
        const r = Math.round(p.r + (p.targetR - p.r) * colorMix);
        const g = Math.round(p.g + (p.targetG - p.g) * colorMix);
        const b = Math.round(p.b + (p.targetB - p.b) * colorMix);

        const radius = Math.max(0.7, p.size * perspScale * (1 - ease * 0.25));
        const alpha = globalAlpha * (1 - ease * 0.25);

        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha.toFixed(3)})`;
        ctx.beginPath();
        ctx.arc(screenX, screenY, radius, 0, Math.PI * 2);
        ctx.fill();
      }
    };

    const syncTriggerProgress = () => {
      if (scrollTriggerInstance) {
        renderAtProgress(scrollTriggerInstance.progress);
      } else {
        renderAtProgress(currentProgress);
      }
    };

    const imgLoader = new Image();
    imgLoader.crossOrigin = 'anonymous';
    imgLoader.onload = () => {
      buildParticles(imgLoader);
      ScrollTrigger.refresh();
      syncTriggerProgress();
    };
    imgLoader.src = src;

    scrollTriggerInstance = ScrollTrigger.create({
      trigger: wrapper,
      start: () => {
        if (isCompactViewport) {
          // Wait until the full portrait has scrolled cleanly into view and begins crossing the header
          return 'top 56px';
        }
        // On desktop, ensure scrollY=0 always shows 100% intact photo before breaking on downward scroll
        const naturalTop = wrapper.getBoundingClientRect().top + window.scrollY;
        const startOffset = Math.min(84, Math.max(20, Math.round(naturalTop - 24)));
        return `top ${startOffset}px`;
      },
      end: 'bottom -80px',
      scrub: true,
      invalidateOnRefresh: true,
      onUpdate: (self) => {
        renderAtProgress(self.progress);
      },
    });

    const onResize = () => {
      if (imgLoader.complete && imgLoader.naturalWidth > 0) {
        buildParticles(imgLoader);
      }
      ScrollTrigger.refresh();
    };
    window.addEventListener('resize', onResize, { passive: true });

    return () => {
      cancelled = true;
      window.removeEventListener('resize', onResize);
      scrollTriggerInstance?.kill();
      if (imgEl) {
        imgEl.style.opacity = '1';
      }
    };
  }, [src, reducedMotion, isCompactViewport, imageError]);

  return (
    <div ref={wrapperRef} className="relative aspect-[4/4.6] w-full overflow-visible rounded-xl">
      {/* Accessible Non-Animated Fallback / Base Portrait */}
      <div className="relative h-full w-full overflow-hidden rounded-xl bg-[#EAE6F0]">
        {!imageError ? (
          <img
            ref={imgRef}
            src={src}
            alt={alt}
            onError={() => setImageError(true)}
            referrerPolicy="no-referrer"
            className="h-full w-full object-cover object-top transition-transform duration-500"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-[#100C16] p-6 text-center">
            <span className="font-display text-4xl font-bold text-[#FF557F]">
              {portfolioConfig.brand.monogram}
            </span>
            <span className="mt-2 text-sm text-[#A69EAC]">
              {portfolioConfig.personal.displayName}
            </span>
          </div>
        )}

        {/* Measured bottom scrim for legibility and seamless dark integration */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-[#09070D] via-[#09070D]/60 to-transparent"
        />

        {/* Portrait Caption inside scrim */}
        <div className="absolute inset-x-4 bottom-4 flex items-end justify-between gap-2">
          <div>
            <p className="font-display text-base font-semibold text-[#F5F1F7]">
              {portfolioConfig.personal.displayName}
            </p>
            <p className="text-xs text-[#A69EAC]">{portfolioConfig.brand.domain}</p>
          </div>
          <span className="font-mono text-xs text-[#FF557F]">
            {portfolioConfig.brand.monogram}
          </span>
        </div>
      </div>

      {/* 3D Scroll-Driven Particle Canvas Overlay */}
      {!reducedMotion && !imageError && (
        <canvas
          ref={canvasRef}
          aria-hidden="true"
          className={`pointer-events-none absolute z-20 ${
            particlesReady ? 'opacity-100' : 'opacity-0'
          }`}
        />
      )}
    </div>
  );
}
