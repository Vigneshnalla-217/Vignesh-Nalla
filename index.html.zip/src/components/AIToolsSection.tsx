import { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, Bot, Compass, Cpu, Sparkles, Terminal } from 'lucide-react';
import { AIToolCategory, AIToolItem, portfolioConfig } from '../data/portfolioConfig';
import { useDeviceCapabilities } from '../hooks/useDeviceCapabilities';
import { SectionHeader } from './SectionHeader';
import { TiltSurface } from './TiltSurface';

type FilterTab = 'All' | AIToolCategory;

const categoryIconMap: Record<AIToolCategory, typeof Sparkles> = {
  'Currently Using': Sparkles,
  'Currently Learning': Terminal,
  'Interested in Exploring': Compass,
};

export function AIToolsSection() {
  const { reducedMotion } = useDeviceCapabilities();
  const [activeFilter, setActiveFilter] = useState<FilterTab>('All');
  const [selectedTool, setSelectedTool] = useState<AIToolItem>(portfolioConfig.aiTools.items[0]);

  const filteredTools = useMemo(() => {
    if (activeFilter === 'All') return portfolioConfig.aiTools.items;
    return portfolioConfig.aiTools.items.filter((tool) => tool.category === activeFilter);
  }, [activeFilter]);

  return (
    <section id="ai-tools" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-5 sm:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <SectionHeader
            index="04"
            eyebrow="AI Tools"
            title={portfolioConfig.aiTools.heading}
            description={portfolioConfig.aiTools.subheading}
          />

          {/* Interactive Filter Controls */}
          <div
            role="tablist"
            aria-label="Filter AI tools by learning stage"
            className="flex flex-wrap items-center gap-1.5 rounded-xl border border-white/[0.08] bg-[#100C16] p-1.5 shrink-0"
          >
            {portfolioConfig.aiTools.categories.map((cat) => {
              const isSelected = activeFilter === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => setActiveFilter(cat)}
                  className={`rounded-lg px-3.5 py-2 text-xs font-medium transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#FF557F] ${
                    isSelected
                      ? 'bg-gradient-to-r from-[#FF557F] to-[#9272FF] text-[#09070D] font-semibold'
                      : 'text-[#A69EAC] hover:text-[#F5F1F7]'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Interactive Grid + Selected Detail Panel */}
        <div className="mt-12 grid grid-cols-1 gap-8 lg:grid-cols-12">
          {/* Tool Cards Grid */}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:col-span-8 xl:grid-cols-3">
            {filteredTools.map((tool, idx) => {
              const isSelected = selectedTool.id === tool.id;
              const CatIcon = categoryIconMap[tool.category];

              return (
                <motion.div
                  key={tool.id}
                  initial={reducedMotion ? false : { opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{
                    duration: 0.35,
                    delay: idx * 0.04,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <TiltSurface maxTiltDeg={4} className="h-full">
                    <button
                      type="button"
                      onClick={() => setSelectedTool(tool)}
                      className={`group flex h-full w-full flex-col justify-between rounded-2xl border p-5 text-left transition-all duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FF557F] ${
                        isSelected
                          ? 'border-[#FF557F]/60 bg-[#150E1F] shadow-[0_12px_36px_rgba(255,85,127,0.12)]'
                          : 'border-white/[0.09] bg-[#100C16]/85 hover:border-[#9272FF]/50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2">
                          <span
                            className="font-mono text-[11px] font-medium"
                            style={{ color: tool.accentHex }}
                          >
                            {tool.category}
                          </span>
                          <CatIcon
                            className="h-4 w-4 shrink-0 transition-transform duration-200 group-hover:scale-110"
                            style={{ color: tool.accentHex }}
                          />
                        </div>

                        <h3 className="mt-3 font-display text-lg font-bold text-[#F5F1F7]">
                          {tool.name}
                        </h3>
                        <p className="mt-1 text-xs font-medium text-[#C44D9E]">{tool.role}</p>
                        <p className="mt-2.5 text-xs leading-relaxed text-[#A69EAC]">
                          {tool.summary}
                        </p>
                      </div>

                      <div className="mt-4 flex items-center justify-between border-t border-white/[0.07] pt-3 text-[11px] font-medium text-[#A69EAC]">
                        <span>{isSelected ? 'Inspecting focus' : 'Inspect details'}</span>
                        <span className="font-mono text-[#F5F1F7]">→</span>
                      </div>
                    </button>
                  </TiltSurface>
                </motion.div>
              );
            })}
          </div>

          {/* Interactive Inspector Column */}
          <div className="lg:col-span-4">
            <div className="sticky top-24 rounded-2xl border border-white/[0.1] bg-[#100C16]/95 p-6 sm:p-7">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs font-medium text-[#A69EAC]">
                  <Bot className="h-4 w-4 text-[#FF557F]" />
                  <span>Tool Focus Inspector</span>
                </div>
                <Cpu className="h-4 w-4 text-[#9272FF]" />
              </div>

              <div className="mt-6 border-t border-white/[0.08] pt-5">
                <p
                  className="font-mono text-xs font-medium"
                  style={{ color: selectedTool.accentHex }}
                >
                  {selectedTool.category}
                </p>
                <h3 className="mt-1.5 font-display text-2xl font-bold text-[#F5F1F7]">
                  {selectedTool.name}
                </h3>
                <p className="mt-1 text-sm font-medium text-[#C44D9E]">{selectedTool.role}</p>

                <p className="mt-4 text-sm leading-relaxed text-[#A69EAC]">
                  {selectedTool.summary}
                </p>

                <div className="mt-5 rounded-xl border border-white/[0.08] bg-[#09070D] p-4">
                  <p className="text-xs font-semibold text-[#F5F1F7]">How I Approach It</p>
                  <p className="mt-1.5 text-xs leading-relaxed text-[#A69EAC]">
                    {selectedTool.learningFocus}
                  </p>
                </div>

                <div className="mt-6 flex items-center justify-between gap-4 border-t border-white/[0.08] pt-5">
                  <span className="text-xs text-[#A69EAC]">Beginner-honest status</span>
                  <a
                    href={selectedTool.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-[#09070D] px-3.5 py-2 text-xs font-semibold text-[#F5F1F7] transition-colors hover:border-[#FF557F]/55 whitespace-nowrap shrink-0"
                  >
                    <span>Visit {selectedTool.name}</span>
                    <ArrowUpRight className="h-3.5 w-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
